
document.getElementById("orderForm").addEventListener("submit", async function (e) {
  e.preventDefault();
  const checked = [...document.querySelectorAll("input[name='food']:checked")].map(el => el.value);
  const date = document.getElementById("date").value;
  const time = document.getElementById("time").value;

  if (checked.length === 0) {
    alert("Silakan pilih minimal satu makanan!");
    return;
  }

  const response = await fetch("/submit-order", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ foods: checked, date, time })
  });

  if (response.ok) {
    alert("Pesanan berhasil dikirim!");
  } else {
    alert("Gagal mengirim pesanan.");
  }
});
